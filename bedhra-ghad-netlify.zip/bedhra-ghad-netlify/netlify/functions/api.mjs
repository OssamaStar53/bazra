import crypto from 'node:crypto';
import { db, env, eq, enc, sleep, httpErr, sign, verify, hashCode, newCode, safeEqual, tgSecret, tg, tgSend,
  waChannelPost, notifyStudents, BRANCHES, DAYS, matches, whenTxt, reminderText, nextOccLocal, localNow } from '../lib/common.mjs';

export const config = { path: '/api/*' };

const json = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
const str = (v, m = 200) => String(v == null ? '' : v).trim().slice(0, m);
const uid = () => crypto.randomUUID().replace(/-/g, '').slice(0, 10);
const today = () => localNow().toISOString().slice(0, 10);
const isUrl = v => /^https?:\/\/\S+$/i.test(v);
const DAY30 = 30 * 86400000;
const KINDS = ['lesson', 'summary', 'exercises', 'bac'];
const PUBLIC_SETTINGS = ['tgChannel', 'tgBot', 'waChannel', 'waGroup'];

const TEACHER_OPS = ['addSession', 'delSession', 'saveAtt', 'addRes', 'delRes', 'addQuiz', 'delQuiz', 'addNote', 'delNote'];
const PERMS = {
  student: ['submitQuiz'],
  teacher: TEACHER_OPS,
  admin: [...TEACHER_OPS, 'addTeacher', 'delTeacher', 'resetTeacherCode', 'postAnn', 'delAnn', 'delStudent', 'resetStudentCode', 'saveSettings', 'broadcast', 'telegramSetup']
};

export default async (req) => {
  const url = new URL(req.url);
  const route = url.pathname.replace(/^\/api\/?/, '').replace(/\/$/, '');
  try {
    if (route === 'health' && req.method === 'GET') return health();
    if (route === 'state' && req.method === 'GET') return json(await buildState(authOf(req)));
    if (route === 'login' && req.method === 'POST') return await login(await body(req));
    if (route === 'register' && req.method === 'POST') return await register(await body(req));
    if (route === 'op' && req.method === 'POST') {
      const auth = authOf(req);
      if (!auth) throw httpErr(401, 'انتهت الجلسة، سجّل الدخول من جديد');
      return json(await runOp(auth, await body(req), url.origin));
    }
    if (route === 'telegram' && req.method === 'POST') return await telegramHook(req);
    return json({ error: 'غير موجود' }, 404);
  } catch (e) {
    if (e.status) return json({ error: e.message }, e.status);
    console.error(e);
    return json({ error: 'حدث خطأ في الخادم' }, 500);
  }
};

async function body(req) { try { return await req.json(); } catch { throw httpErr(400, 'طلب غير صالح'); } }
function authOf(req) {
  const p = verify((req.headers.get('authorization') || '').replace(/^Bearer\s+/i, ''));
  return p && ['student', 'teacher', 'admin'].includes(p.role) ? p : null;
}
async function health() {
  const e = { supabase: !!(env('SUPABASE_URL') && env('SUPABASE_SERVICE_KEY')), auth_secret: env('AUTH_SECRET').length >= 24, admin_password: env('ADMIN_PASSWORD').length >= 8,
    telegram_bot: !!env('TELEGRAM_BOT_TOKEN'), telegram_channel: !!env('TELEGRAM_CHANNEL'), whatsapp: env('WA_PROVIDER') || 'none' };
  let dbOk = false;
  try { await db.one('settings', 'select=key'); dbOk = true; } catch {}
  return json({ ok: e.supabase && e.auth_secret && e.admin_password && dbOk, env: e, db: dbOk });
}

/* ---------- الحالة حسب الدور ---------- */
async function buildState(auth) {
  const [teachers, sessions, res, ann, quizzes, setRows, ids] = await Promise.all([
    db.all('teachers', 'select=id,name,subject'), db.all('sessions', 'select=*'), db.all('res', 'select=*'),
    db.all('ann', 'select=*'), db.all('quizzes', 'select=*'), db.all('settings', 'select=*'), db.all('students', 'select=id')
  ]);
  const settings = {}; setRows.forEach(r => { if (PUBLIC_SETTINGS.includes(r.key)) settings[r.key] = r.value; });
  const state = {
    teachers, sessions, res, ann, settings,
    quizzes: quizzes.map(q => ({ ...q, questions: (q.questions || []).map(x => ({ q: x.q, o: x.o })) })), // بدون الإجابات الصحيحة
    students: [], att: [], results: [], notes: [], counts: { students: ids.length, teachers: teachers.length }
  };
  let role = 'guest', uidv = null;
  if (auth && auth.role === 'admin') {
    role = 'admin';
    state.students = (await db.all('students', 'select=id,name,branch,subjects,phone,notify,joined,tg_chat_id')).map(({ tg_chat_id, ...s }) => ({ ...s, tg: !!tg_chat_id }));
    [state.att, state.results, state.notes] = await Promise.all([db.all('att', 'select=*'), db.all('results', 'select=*'), db.all('notes', 'select=*')]);
  } else if (auth && auth.role === 'teacher' && teachers.some(t => t.id === auth.id)) {
    role = 'teacher'; uidv = auth.id;
    state.students = await db.all('students', 'select=id,name,branch,subjects,joined');
    [state.att, state.results, state.notes] = await Promise.all([db.all('att', 'select=*'), db.all('results', 'select=*'), db.all('notes', 'select=*')]);
  } else if (auth && auth.role === 'student') {
    const me = await db.one('students', `select=id,name,branch,subjects,phone,notify,joined,link_code&${eq('id', auth.id)}`);
    if (me) {
      role = 'student'; uidv = me.id; state.students = [me];
      [state.att, state.results, state.notes] = await Promise.all([
        db.all('att', `select=*&${eq('sid', me.id)}`), db.all('results', `select=*&${eq('sid', me.id)}`), db.all('notes', `select=*&${eq('sid', me.id)}`)]);
    }
  }
  return { role, uid: uidv, state };
}

/* ---------- الدخول والتسجيل ---------- */
async function login(b) {
  const role = str(b.role, 10), code = str(b.code, 80);
  let ok = null;
  if (code) {
    if (role === 'admin') { if (env('ADMIN_PASSWORD') && safeEqual(code, env('ADMIN_PASSWORD'))) ok = { role: 'admin', id: 'admin' }; }
    else if (role === 'student') { const s = await db.one('students', `select=id&${eq('code_hash', hashCode(code))}`); if (s) ok = { role, id: s.id }; }
    else if (role === 'teacher') { const t = await db.one('teachers', `select=id&${eq('id', str(b.id, 30))}&${eq('code_hash', hashCode(code))}`); if (t) ok = { role, id: t.id }; }
  }
  if (!ok) { await sleep(600); throw httpErr(401, 'الرمز غير صحيح'); }
  return json({ token: sign({ ...ok, exp: Date.now() + DAY30 }) });
}
async function register(b) {
  const name = str(b.name, 80), branch = str(b.branch, 40);
  const subjects = Array.isArray(b.subjects) ? [...new Set(b.subjects.map(x => str(x, 60)).filter(Boolean))].slice(0, 12) : [];
  if (name.length < 3 || !BRANCHES.includes(branch) || !subjects.length) throw httpErr(400, 'بيانات التسجيل غير مكتملة');
  const code = newCode(), id = uid(), link = newCode();
  await db.insert('students', [{ id, name, branch, subjects, phone: str(b.phone, 20), notify: ['telegram', 'whatsapp', 'none'].includes(b.notify) ? b.notify : 'telegram', link_code: link, code_hash: hashCode(code), joined: today() }]);
  return json({ token: sign({ role: 'student', id, exp: Date.now() + DAY30 }), code });
}

/* ---------- العمليات ---------- */
async function runOp(auth, b, origin) {
  const op = str(b.op, 30);
  if (!(PERMS[auth.role] || []).includes(op)) throw httpErr(403, 'غير مسموح');
  const adm = auth.role === 'admin';
  const own = async (table, id) => {
    const r = await db.one(table, `select=*&${eq('id', str(id, 30))}`);
    if (!r) throw httpErr(404, 'غير موجود');
    if (!adm && r.tid !== auth.id) throw httpErr(403, 'غير مسموح');
    return r;
  };
  switch (op) {
    case 'addSession': {
      const day = Number(b.day), time = str(b.time, 5), subject = str(b.subject, 60), branch = str(b.branch, 40) || 'الكل';
      if (!subject || !(day >= 0 && day <= 6) || !/^\d{2}:\d{2}$/.test(time) || (branch !== 'الكل' && !BRANCHES.includes(branch))) throw httpErr(400, 'بيانات الحصة غير صحيحة');
      await db.insert('sessions', [{ id: uid(), subject, branch, day, time, label: str(b.label, 60), place: str(b.place, 80) || 'دار الشباب', tid: adm ? (str(b.tid, 30) || null) : auth.id }]);
      return {};
    }
    case 'delSession': { const s = await own('sessions', b.id); await db.del('att', eq('sess', s.id)); await db.del('sessions', eq('id', s.id)); return {}; }
    case 'saveAtt': {
      const s = await own('sessions', b.sess), date = str(b.date, 10);
      if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !Array.isArray(b.marks) || !b.marks.length) throw httpErr(400, 'بيانات الحضور غير صحيحة');
      await db.upsert('att', b.marks.slice(0, 500).map(m => ({ sid: str(m.sid, 30), sess: s.id, date, present: !!m.present })), 'sid,sess,date');
      return {};
    }
    case 'addRes': {
      const kind = str(b.kind, 12), title = str(b.title, 120), bodyTxt = str(b.body, 20000), link = str(b.link, 500);
      if (!KINDS.includes(kind) || !title) throw httpErr(400, 'أدخل النوع والعنوان');
      if (link && !isUrl(link)) throw httpErr(400, 'الرابط يجب أن يبدأ بـ https://');
      if (kind !== 'bac' && !bodyTxt && !link) throw httpErr(400, 'أضف نصًا أو رابطًا');
      await db.insert('res', [{ id: uid(), kind, title, subject: str(b.subject, 60), branch: str(b.branch, 40) || 'الكل', tid: adm ? null : auth.id, date: today(), body: bodyTxt, link }]);
      return {};
    }
    case 'delRes': { const r = await own('res', b.id); await db.del('res', eq('id', r.id)); return {}; }
    case 'addQuiz': {
      const title = str(b.title, 120), qs = Array.isArray(b.questions) ? b.questions.slice(0, 100) : [];
      const questions = qs.map(x => ({ q: str(x.q, 400), o: (Array.isArray(x.o) ? x.o : []).slice(0, 4).map(o => str(o, 200)), a: Number(x.a) }));
      if (!title || !questions.length || questions.some(x => !x.q || x.o.length !== 4 || x.o.some(o => !o) || !Number.isInteger(x.a) || x.a < 0 || x.a > 3)) throw httpErr(400, 'بيانات الاختبار غير صحيحة');
      await db.insert('quizzes', [{ id: uid(), title, subject: str(b.subject, 60), branch: str(b.branch, 40) || 'الكل', minutes: Math.max(1, Math.min(180, parseInt(b.minutes, 10) || 30)), tid: adm ? null : auth.id, questions }]);
      return {};
    }
    case 'delQuiz': { const q = await own('quizzes', b.id); await db.del('quizzes', eq('id', q.id)); return {}; }
    case 'addNote': {
      const sid = str(b.sid, 30), text = str(b.text, 1000);
      if (!text || !(await db.one('students', `select=id&${eq('id', sid)}`))) throw httpErr(400, 'اختر التلميذ واكتب الملاحظة');
      const t = adm ? null : await db.one('teachers', `select=subject&${eq('id', auth.id)}`);
      await db.insert('notes', [{ id: uid(), sid, tid: adm ? null : auth.id, subject: t ? t.subject : '', date: today(), text }]);
      return {};
    }
    case 'delNote': { const n = await own('notes', b.id); await db.del('notes', eq('id', n.id)); return {}; }

    case 'addTeacher': {
      const name = str(b.name, 80), subject = str(b.subject, 60);
      if (name.length < 3 || !subject) throw httpErr(400, 'أدخل الاسم والمادة');
      const code = newCode();
      await db.insert('teachers', [{ id: uid(), name, subject, code_hash: hashCode(code) }]);
      return { code };
    }
    case 'resetTeacherCode': {
      const id = str(b.id, 30); if (!(await db.one('teachers', `select=id&${eq('id', id)}`))) throw httpErr(404, 'غير موجود');
      const code = newCode(); await db.update('teachers', eq('id', id), { code_hash: hashCode(code) }); return { code };
    }
    case 'delTeacher': {
      const id = str(b.id, 30);
      for (const t of ['sessions', 'res', 'quizzes', 'notes']) await db.update(t, eq('tid', id), { tid: null });
      await db.del('teachers', eq('id', id)); return {};
    }
    case 'postAnn': {
      const title = str(b.title, 120), text = str(b.text, 1500), branch = str(b.branch, 40) || 'الكل';
      if (!title || !text || (branch !== 'الكل' && !BRANCHES.includes(branch))) throw httpErr(400, 'أدخل العنوان والنص');
      await db.insert('ann', [{ id: uid(), title, text, date: today(), branch }]);
      let tgOk = null;
      if (b.tg) tgOk = env('TELEGRAM_CHANNEL') ? await tgSend(env('TELEGRAM_CHANNEL'), `📢 ${title}\n${text}`) : false;
      return { tg: tgOk };
    }
    case 'delAnn': await db.del('ann', eq('id', str(b.id, 30))); return {};
    case 'delStudent': {
      const id = str(b.id, 30);
      for (const t of ['att', 'results', 'notes']) await db.del(t, eq('sid', id));
      await db.del('students', eq('id', id)); return {};
    }
    case 'resetStudentCode': {
      const id = str(b.id, 30); if (!(await db.one('students', `select=id&${eq('id', id)}`))) throw httpErr(404, 'غير موجود');
      const code = newCode(); await db.update('students', eq('id', id), { code_hash: hashCode(code) }); return { code };
    }
    case 'saveSettings': {
      const rows = PUBLIC_SETTINGS.map(k => ({ key: k, value: str(b[k], 200) }));
      for (const r of rows) if ((r.key === 'waChannel' || r.key === 'waGroup') && r.value && !isUrl(r.value)) throw httpErr(400, 'روابط واتساب يجب أن تبدأ بـ https://');
      await db.upsert('settings', rows, 'key'); return {};
    }
    case 'broadcast': {
      const text = str(b.text, 1500), to = Array.isArray(b.to) ? b.to : [], branch = str(b.branch, 40), out = {};
      if (!text) throw httpErr(400, 'اكتب الرسالة');
      if (to.includes('telegram_channel')) out.telegram_channel = env('TELEGRAM_CHANNEL') ? await tgSend(env('TELEGRAM_CHANNEL'), text) : false;
      if (to.includes('whatsapp_channel')) out.whatsapp_channel = await waChannelPost(text);
      if (to.includes('students')) {
        const list = (await db.all('students', 'select=id,branch,phone,notify,tg_chat_id')).filter(s => !branch || branch === 'الكل' || s.branch === branch);
        out.students = await notifyStudents(list, text);
      }
      return out;
    }
    case 'telegramSetup': {
      const me = await tg('getMe');
      await tg('setWebhook', { url: origin + '/api/telegram', secret_token: tgSecret(), allowed_updates: ['message'] });
      await db.upsert('settings', [{ key: 'tgBot', value: me.username }], 'key');
      return { username: me.username };
    }
    case 'submitQuiz': {
      const q = await db.one('quizzes', `select=*&${eq('id', str(b.quizId, 30))}`);
      if (!q) throw httpErr(404, 'الاختبار غير موجود');
      const answers = Array.isArray(b.answers) ? b.answers : [], qs = q.questions || [];
      const score = qs.reduce((n, it, i) => n + (answers[i] === it.a ? 1 : 0), 0);
      await db.insert('results', [{ id: uid(), sid: auth.id, quiz: q.id, subject: q.subject, score, total: qs.length, date: today() }]);
      return { score, total: qs.length, correct: qs.map(x => x.a) };
    }
  }
  throw httpErr(400, 'عملية غير معروفة');
}

/* ---------- بوت تيليغرام (Webhook) ---------- */
async function telegramHook(req) {
  if (req.headers.get('x-telegram-bot-api-secret-token') !== tgSecret()) return json({ ok: false }, 401);
  const u = await req.json().catch(() => null);
  if (u && u.message && u.message.text) await handleMsg(u.message).catch(e => console.error('tg msg', e.message));
  return json({ ok: true });
}
async function handleMsg(msg) {
  const chat = String(msg.chat.id), [cmd, arg] = msg.text.trim().split(/\s+/);
  const me = await db.one('students', `select=*&${eq('tg_chat_id', chat)}`);
  if (cmd === '/start' && arg) {
    const s = await db.one('students', `select=*&${eq('link_code', str(arg, 40))}`);
    if (!s) return void await tgSend(chat, 'الرمز غير صحيح. افتح بطاقتك في الموقع واضغط «ربط حسابي بالبوت».');
    await db.update('students', eq('id', s.id), { tg_chat_id: chat });
    return void await tgSend(chat, `مرحبًا ${s.name} 🌱\nتم ربط حسابك. ستصلك تذكيرات الحصص هنا.\n/next الحصة القادمة\n/sessions كل حصصك`);
  }
  if (!me) return void await tgSend(chat, 'مرحبًا بك في بذرة غد. لربط حسابك افتح بطاقتك في الموقع واضغط «ربط حسابي بالبوت».');
  const mine = (await db.all('sessions', 'select=*')).filter(se => matches(me, se));
  if (cmd === '/sessions') return void await tgSend(chat, mine.length ? mine.map(se => `• ${se.subject}: ${DAYS[se.day]} ${whenTxt(se)} – ${se.place}`).join('\n') : 'لا توجد حصص لموادك حاليًا.');
  if (cmd === '/next') {
    const now = localNow(), n = mine.map(se => ({ se, t: nextOccLocal(se, now) })).filter(x => x.t).sort((a, b) => a.t - b.t)[0];
    return void await tgSend(chat, n ? reminderText(n.se) : 'لا توجد حصة قادمة.');
  }
  return void await tgSend(chat, '/next الحصة القادمة\n/sessions كل حصصك');
}

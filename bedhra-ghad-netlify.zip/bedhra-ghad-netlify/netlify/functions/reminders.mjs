// وظيفة مجدولة: تذكير التلاميذ قبل الحصص وإعلان في قناة تيليغرام
import { db, env, eq, tgSend, notifyStudents, matches, reminderText, localNow, nextOccLocal } from '../lib/common.mjs';

export default async () => {
  const hours = Number(env('REMINDER_HOURS') || 3), now = localNow();
  const [sessions, students] = await Promise.all([
    db.all('sessions', 'select=*'),
    db.all('students', 'select=id,branch,subjects,phone,notify,tg_chat_id')
  ]);
  for (const se of sessions) {
    const t = nextOccLocal(se, now);
    if (!t || (t - now) / 3600000 > hours) continue;
    const key = `${se.id}:${t.toISOString().slice(0, 10)}`;
    if (await db.one('sent', `select=key&${eq('key', key)}`)) continue;
    await db.insert('sent', [{ key, at: new Date().toISOString() }]); // نسجّل أولًا لتفادي التكرار
    const text = reminderText(se);
    await notifyStudents(students.filter(s => matches(s, se)), text);
    if (env('TELEGRAM_CHANNEL')) await tgSend(env('TELEGRAM_CHANNEL'), text);
    console.log('reminder sent', key);
  }
};
export const config = { schedule: '*/10 * * * *' };

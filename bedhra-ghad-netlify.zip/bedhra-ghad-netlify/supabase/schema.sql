-- شغّل هذا الملف كاملًا في Supabase: SQL Editor > New query > Run
create table if not exists teachers(
  id text primary key, name text not null, subject text not null, code_hash text not null, created timestamptz default now());
create table if not exists students(
  id text primary key, name text not null, branch text not null, subjects jsonb not null,
  phone text default '', notify text default 'telegram', tg_chat_id text,
  link_code text unique not null, code_hash text not null, joined date default current_date);
create index if not exists students_code on students(code_hash);
create index if not exists students_tg on students(tg_chat_id);
create table if not exists sessions(
  id text primary key, subject text not null, branch text not null, day int not null, "time" text not null,
  label text default '', place text default 'دار الشباب', tid text);
create table if not exists att(
  sid text not null, sess text not null, "date" date not null, present boolean not null,
  primary key(sid, sess, "date"));
create table if not exists results(
  id text primary key, sid text not null, quiz text, subject text, score int not null, total int not null, "date" date default current_date);
create index if not exists results_sid on results(sid);
create table if not exists quizzes(
  id text primary key, title text not null, subject text, branch text default 'الكل', minutes int default 30, tid text, questions jsonb not null);
create table if not exists res(
  id text primary key, kind text not null, title text not null, subject text, branch text default 'الكل', tid text,
  "date" date default current_date, body text default '', link text default '');
create table if not exists ann(
  id text primary key, title text not null, "text" text not null, "date" date default current_date, branch text default 'الكل');
create table if not exists notes(
  id text primary key, sid text not null, tid text, subject text, "date" date default current_date, "text" text not null);
create table if not exists settings("key" text primary key, value text);
create table if not exists sent("key" text primary key, at timestamptz default now());

-- حماية: تفعيل RLS بدون سياسات = لا أحد يصل للبيانات إلا الخادم بمفتاح service_role
alter table teachers enable row level security;
alter table students enable row level security;
alter table sessions enable row level security;
alter table att enable row level security;
alter table results enable row level security;
alter table quizzes enable row level security;
alter table res enable row level security;
alter table ann enable row level security;
alter table notes enable row level security;
alter table settings enable row level security;
alter table sent enable row level security;
